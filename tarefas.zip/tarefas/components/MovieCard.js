// components/MovieCard.js

import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const MovieCard = ({ movie, onPress }) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.card}>
      <Image source={movie.image} style={styles.image} />
      <Text style={styles.title}>{movie.title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: { marginRight: 10 },
  image: { width: 120, height: 180, borderRadius: 8 },
  title: { textAlign: 'center', marginTop: 5 },
});

export default MovieCard;
